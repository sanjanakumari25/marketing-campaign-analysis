setwd("~/AAMD PROJECT")
list.files()
data <- read.csv("marketing_campaign_cleaned.csv")
library(rpart)
library(rpart.plot)
head(data)
str(data)
data$Response <- as.factor(data$Response)
data$Dt_Customer <- NULL
data$ID <- NULL
str(data)

set.seed(123)   
n <- nrow(data)
train_index <- sample(1:n, size = 0.7 * n)

train <- data[train_index, ]
test  <- data[-train_index, ]

model<- rpart( Response ~ ., data = train,method="class",
                       control = rpart.control(minsplit = 20,  cp = 0.01  ))

rpart.plot(model)
model

library(caret)
printcp(model)
plotcp(model)

bestcp <- model$cptable[
  which.min(model$cptable[, "xerror"]),
  "CP"]
data_pruned <- prune(model, cp = bestcp)
rpart.plot(data_pruned)
data_pruned
library(caret)

set.seed(123)

ctrl <- trainControl(
  method = "cv",
  number = 5)

cv_tree <- train(
  Response ~ .,
  data = data_model,
  method = "rpart",
  trControl = ctrl)

varImp(cv_tree)


train_pred <- predict(data_pruned, train, type = "class")
test_pred  <- predict(data_pruned, test, type = "class")

confusionMatrix(train_pred, train$Response)
confusionMatrix(test_pred, test$Response)


library(pROC)

# Predict probabilities
train_prob_tree <- predict(data_pruned, train, type = "prob")[,2]
test_prob_tree  <- predict(data_pruned, test,  type = "prob")[,2]

# ROC curves
roc_train_tree <- roc(train$Response, train_prob_tree)
roc_test_tree  <- roc(test$Response,  test_prob_tree)

# Plot ROC
plot(roc_train_tree, main = "ROC Curve – Decision Tree (Train)")
plot(roc_test_tree,  main = "ROC Curve – Decision Tree (Test)")

# AUC values
auc(roc_train_tree)
auc(roc_test_tree)

