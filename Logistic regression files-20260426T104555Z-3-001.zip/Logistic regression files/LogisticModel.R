# Logistics Regression Model 

# Set working directory 
setwd("~/Downloads/project")

# Installs the required packages for model evaluation
install.packages("pROC")     # for ROC curve and AUC calculation
install.packages("caret")    # for cross-validation and and model training
install.packages("PRROC")

library(pROC)
library(caret)
library(PRROC)

# Fix random number generation for reproducibility
set.seed(123)

# Shows all files inside the working directory
list.files()

# Data preparation 
# Loads dataset 
data <- read.csv("marketing_campaign_clean.csv")

# Convert Response to factor and set baseline (0 = No response)
data$Response <- as.factor(data$Response)
data$Response <- relevel(data$Response, ref = "0") 

# Drop variables we don't want as predictors
data_model <- subset(data, select = -c(Dt_Customer, Year_Birth))

# 3. Train / Test split (70% train, 30% test)
n <- nrow(data_model)  # Stores total number of rows in the dataset
train_idx <- sample(1:n, size = round(0.7 * n), replace = FALSE)   # Randomly selects 70% of rows for training
train <- data_model[train_idx, ]
test <- data_model[-train_idx, ]

# Fit logistic regression with a reasonable set of predictors
my_model <- glm(
  Response ~ Income + Recency +
    MntWines + MntMeatProducts +
    NumWebPurchases + NumWebVisitsMonth +
    AcceptedCmp1 + AcceptedCmp2 + AcceptedCmp3 + AcceptedCmp4 + AcceptedCmp5 +
    Complain +
    Education_Basic + Education_Graduation + Education_Master + Education_PhD +
    Marital_Status_Alone + Marital_Status_Divorced + Marital_Status_Married +
    Marital_Status_Single + Marital_Status_Together + Marital_Status_Widow +
    Marital_Status_Yolo,
  data    = train,
  family  = "binomial"
)

summary(my_model)

# Stepwise model 
my_model_step <- step(my_model)
summary(my_model_step)

# Show which variables stepwise kept
step_vars <- names(coef(my_model_step))
cat("\nVariables in stepwise model:\n")
print(step_vars)

# Predicts probability of Response = 1 for training and test data
train_pred_prob <- predict(my_model_step, newdata = train, type = "response")
test_pred_prob  <- predict(my_model_step, newdata = test,  type = "response")

# Export results for Excel
train_out <- data.frame(
  ID        = train$ID,
  set       = "train",
  Response  = train$Response,
  pred_prob = train_pred_prob
)

test_out <- data.frame(
  ID        = test$ID,
  set       = "test",
  Response  = test$Response,
  pred_prob = test_pred_prob
)

all_out <- rbind(train_out, test_out)
write.csv(all_out, "MC_modellingfile.csv", row.names = FALSE)

# ROC and AUC analysis
library(pROC)

roc_train <- roc(train$Response, train_pred_prob)
auc_train <- auc(roc_train)

roc_test <- roc(test$Response, test_pred_prob)
auc_test <- auc(roc_test)

cat("\nTRAIN AUC:", round(auc_train, 4), "\n")
cat("TEST AUC: ", round(auc_test, 4), "\n")

# Plot ROC curves
par(mar = c(5, 5, 4, 2))

plot(roc_train, col = "blue", main = "ROC Curve: Train vs Test")
plot(roc_test, col = "red", add = TRUE)
legend("bottomright",
       legend = c(paste("Train AUC =", round(auc_train, 3)),
                  paste("Test AUC =", round(auc_test, 3))),
       col = c("blue", "red"), lwd = 2)

# 5-Fold cross validation
# Prepare response for caret
train$ResponseF <- factor(
  ifelse(train$Response == "1", "yes", "no"),
  levels = c("no", "yes")
)

# Cross-validation setup
ctrl <- trainControl(
  method          = "cv",
  number          = 5,
  classProbs      = TRUE,
  summaryFunction = twoClassSummary,
  savePredictions = "final"   # keep fold predictions
)

# Run CV logistic regression
cv_fit <- train(
  ResponseF ~ Income + Recency + MntWines + MntMeatProducts +
    NumWebPurchases + NumWebVisitsMonth +
    AcceptedCmp1 + AcceptedCmp2 + AcceptedCmp3 +
    AcceptedCmp4 + AcceptedCmp5 +
    Complain +
    Education_Basic + Education_Graduation +
    Education_Master + Education_PhD +
    Marital_Status_Alone + Marital_Status_Divorced +
    Marital_Status_Married + Marital_Status_Single +
    Marital_Status_Together + Marital_Status_Widow,
  data      = train,
  method    = "glm",
  family    = "binomial",
  trControl = ctrl,
  metric    = "ROC"
)

cv_auc <- cv_fit$results$ROC[1]
cat("5-FOLD CV AUC:", round(cv_auc, 4), "\n")

# export all 5‑fold CV probabilities
# cv_fit$pred has columns: obs, pred, yes, no, rowIndex, Resample
cv_probs <- cv_fit$pred
# keep probability of "yes"
cv_probs_out <- data.frame(
  row_index = cv_probs$rowIndex,
  fold      = cv_probs$Resample,
  obs       = cv_probs$obs,
  prob_yes  = cv_probs$yes
)
write.csv(cv_probs_out, "MC_cv_probs_5fold.csv", row.names = FALSE)

# Precision–Recall curves (Train & Test)
# Convert to 0/1 numeric for PRROC
y_train <- ifelse(train$Response == "1", 1, 0)
y_test  <- ifelse(test$Response  == "1", 1, 0)

# PR curves using PRROC
pr_train <- pr.curve(
  scores.class0 = train_pred_prob[y_train == 1],
  scores.class1 = train_pred_prob[y_train == 0],
  curve = TRUE
)

pr_test <- pr.curve(
  scores.class0 = test_pred_prob[y_test == 1],
  scores.class1 = test_pred_prob[y_test == 0],
  curve = TRUE
)

par(mar = c(5, 5, 4, 2))
plot(pr_train$curve[,1], pr_train$curve[,2],
     type = "l", col = "blue", lwd = 2,
     xlab = "Recall", ylab = "Precision",
     main = "Precision–Recall Curve: Train vs Test")
lines(pr_test$curve[,1], pr_test$curve[,2],
      col = "red", lwd = 2)
legend("topright",
       legend = c("Train", "Test"),
       col = c("blue", "red"), lwd = 2)

# Threshold‑wise precision & recall (like Excel) 
th <- seq(0.01, 0.99, by = 0.01)

pr_table <- function(p, y, th_vec) {
  sapply(th_vec, function(t0) {
    pred <- ifelse(p >= t0, 1, 0)
    TP <- sum(pred == 1 & y == 1)
    FP <- sum(pred == 1 & y == 0)
    FN <- sum(pred == 0 & y == 1)
    recall    <- ifelse(TP + FN == 0, NA, TP / (TP + FN))
    precision <- ifelse(TP + FP == 0, NA, TP / (TP + FP))
    c(recall = recall, precision = precision)
  })
}

pr_train_tab <- t(pr_table(train_pred_prob, y_train, th))
pr_test_tab  <- t(pr_table(test_pred_prob,  y_test,  th))

thr_pr <- data.frame(
  Threshold       = th,
  Recall_train    = pr_train_tab[, "recall"],
  Recall_test     = pr_test_tab[, "recall"],
  Precision_train = pr_train_tab[, "precision"],
  Precision_test  = pr_test_tab[, "precision"]
)

write.csv(thr_pr, "MC_threshold_PR_train_test.csv", row.names = FALSE)

# Plot threshold vs recall/precision
par(mar = c(5, 5, 4, 2))
plot(th, thr_pr$Recall_train, type = "l", col = "blue", lwd = 2,
     xlab = "Threshold", ylab = "Metric",
     main = "Recall & Precision vs Threshold")
lines(th, thr_pr$Precision_train, col = "darkblue", lwd = 2)
lines(th, thr_pr$Recall_test, col = "red", lwd = 2)
lines(th, thr_pr$Precision_test, col = "darkred", lwd = 2)
legend("right",
       legend = c("Train recall", "Train precision",
                  "Test recall", "Test precision"),
       col = c("blue", "darkblue", "red", "darkred"),
       lwd = 2)


# Final summary
cat("\n=== MODEL PERFORMANCE ===\n")
cat("Train AUC: ", round(auc_train, 3), "\n")
cat("Test  AUC: ", round(auc_test, 3), "\n")
cat("CV AUC:    ", round(cv_auc, 3), "\n")
cat("\nOutput files:\n")
cat("  - MC_modellingfile.csv (train & test probabilities)\n")
cat("  - MC_cv_probs_5fold.csv (5-fold CV probabilities)\n")
cat("  - MC_threshold_PR_train_test.csv (threshold, recall, precision)\n")


