# ==========================================
# STEP 1: CLEANING & OUTLIER REMOVAL
# ==========================================
if (!require("tidyverse")) install.packages("tidyverse")
if (!require("lubridate")) install.packages("lubridate")
if (!require("readxl")) install.packages("readxl")

library(tidyverse)
library(lubridate)
library(readxl)

# 1. SETUP
setwd("C:/Users/hp/Desktop/aamd project")
print("Loading Raw Data...")

# Read Raw Excel (Force all columns to text to prevent crashing)
raw_data <- read_excel("marketing_campaign(raw).xlsx", col_types = "text")
# Convert numbers back to numeric automatically
raw_data <- type_convert(raw_data)

# 2. CLEANING PIPELINE
clean_df <- raw_data %>%
  # --- A. Fix Date Format ---
  mutate(
    Dt_Customer = case_when(
      # If it's an Excel Serial Number (Digits only, no dashes)
      str_detect(Dt_Customer, "^[0-9]+$") & !str_detect(Dt_Customer, "-") ~ 
        as.Date(as.numeric(Dt_Customer), origin = "1899-12-30"),
      # Otherwise, try YMD or DMY formats
      TRUE ~ coalesce(ymd(Dt_Customer, quiet = TRUE), dmy(Dt_Customer, quiet = TRUE))
    )
  ) %>%
  
  # --- B. Create New Variables ---
  mutate(
    Age = 2014 - Year_Birth,
    
    # "Total_Spend" = Sum of all 6 product categories
    Total_Spend = MntWines + MntFruits + MntMeatProducts + 
      MntFishProducts + MntSweetProducts + MntGoldProds,
    
    # "Tenure_Days" = How many days they have been a customer
    Tenure_Days = as.numeric(difftime(max(Dt_Customer, na.rm=TRUE), Dt_Customer, units = "days")),
    
    # "Marital_Status" = Group niche types into Single
    Marital_Status = case_when(
      Marital_Status %in% c("YOLO", "Absurd", "Alone") ~ "Single",
      TRUE ~ Marital_Status
    )
  ) %>%
  
  # --- C. REMOVE OUTLIERS (The Crucial Step) ---
  select(-c(Z_CostContact, Z_Revenue)) %>% # Remove useless columns
  filter(Age < 100) %>%         # Remove the 3 people born in 1900
  filter(Income < 600000) %>%   # Remove the $666,666 outlier
  drop_na()                     # Remove rows with missing values

# 3. SAVE THE CLEAN FILE
print(paste("Original Rows:", nrow(raw_data)))
print(paste("Cleaned Rows:", nrow(clean_df)))

write_csv(clean_df, "marketing_campaign_cleaned.csv")
print("SUCCESS: 'marketing_campaign_cleaned.csv' has been created.")