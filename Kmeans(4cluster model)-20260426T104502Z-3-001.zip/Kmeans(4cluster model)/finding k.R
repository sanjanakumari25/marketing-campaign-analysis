# ==========================================
# SCRIPT 1: FIND THE OPTIMAL K (Discovery)
# =========================================
if (!require("tidyverse")) install.packages("tidyverse")
if (!require("cluster")) install.packages("cluster") 
if (!require("factoextra")) install.packages("factoextra")
if (!require("NbClust")) install.packages("NbClust") 

library(tidyverse)
library(cluster)
library(factoextra)
library(NbClust)

# 1. LOAD THE CLEAN DATA
setwd("C:/Users/hp/Desktop/aamd project")
print("Loading 'marketing_campaign_outliers_removed.csv'...")

# We use read_csv because you saved it as a CSV
df <- read_csv("marketing_campaign_outliers_removed.csv", show_col_types = FALSE)

# 2. PREPARE DATA FOR CLUSTERING
# We select the same 4 strategy variables
cluster_data <- df %>%
  select(Income, Total_Spend, NumWebVisitsMonth, Recency)

# Scale the data (Standardization)
cluster_scaled <- scale(cluster_data)

print("Running Statistical Tests...")

# 3. METHOD A: THE ELBOW PLOT (Visual Check)
p_elbow <- fviz_nbclust(cluster_scaled, kmeans, method = "wss") +
  labs(title = "The Elbow Method", subtitle = "Look for the 'knee' in the curve")
print(p_elbow)

# 4. METHOD B: NbClust (The 30 Indices Check)
# This runs 30 different statistical tests to vote on the best number
set.seed(123)
nb <- NbClust(cluster_scaled, distance = "euclidean", min.nc = 2, max.nc = 6, 
              method = "kmeans", index = "all")

# 5. PRINT THE WINNER
best_k <- as.numeric(names(sort(table(nb$Best.nc[1,]), decreasing=TRUE)[1]))

print("------------------------------------------------")
print(paste("THE SCIENTIFIC CONCLUSION: The Optimal K is", best_k))
print("------------------------------------------------")