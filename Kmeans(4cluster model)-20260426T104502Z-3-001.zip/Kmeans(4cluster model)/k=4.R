# ==========================================
# STEP 3 (Alternative): EXECUTE STRATEGY (K=4)
# ==========================================
if (!require("tidyverse")) install.packages("tidyverse")
if (!require("cluster")) install.packages("cluster") 
if (!require("factoextra")) install.packages("factoextra")
if (!require("gridExtra")) install.packages("gridExtra")

library(tidyverse)
library(cluster)
library(factoextra)
library(gridExtra)

setwd("C:/Users/hp/Desktop/aamd project")

# 1. LOAD CLEAN DATA
print("Loading 'marketing_campaign_cleaned.csv'...")
df <- read_csv("marketing_campaign_cleaned.csv", show_col_types = FALSE)

# 2. RUN K-MEANS (K=4)
cluster_data <- df %>% select(Income, Total_Spend, NumWebVisitsMonth, Recency)
cluster_scaled <- scale(cluster_data)

print("Running K-Means with K=4...")
set.seed(123)
kmeans_result <- kmeans(cluster_scaled, centers = 4, nstart = 25)
df$Cluster <- as.factor(kmeans_result$cluster)

# 3. AUTO-LABEL THE 4 PERSONAS
# We use logic to identify who is who automatically

# Calculate the averages for each cluster
profile <- df %>% 
  group_by(Cluster) %>% 
  summarise(
    Avg_Spend = mean(Total_Spend),
    Avg_Visits = mean(NumWebVisitsMonth),
    Avg_Recency = mean(Recency)
  )

# A. Find STARS (Highest Spend)
stars_id <- profile %>% arrange(desc(Avg_Spend)) %>% slice(1) %>% pull(Cluster)

# B. Find AT RISK (Highest Recency, excluding Stars)
at_risk_id <- profile %>% 
  filter(Cluster != stars_id) %>% 
  arrange(desc(Avg_Recency)) %>% slice(1) %>% pull(Cluster)

# C. Find DISCOUNT HUNTERS (Highest Visits, excluding Stars/At Risk)
hunters_id <- profile %>% 
  filter(!Cluster %in% c(stars_id, at_risk_id)) %>% 
  arrange(desc(Avg_Visits)) %>% slice(1) %>% pull(Cluster)

# D. Find POTENTIALISTS (The one left over)
potential_id <- profile %>% 
  filter(!Cluster %in% c(stars_id, at_risk_id, hunters_id)) %>% 
  pull(Cluster)

# Apply the names
df <- df %>%
  mutate(Persona = case_when(
    Cluster == stars_id ~ "Stars (VIPs)",
    Cluster == hunters_id ~ "Discount Hunters",
    Cluster == at_risk_id ~ "At Risk (Churning)",
    Cluster == potential_id ~ "Potentialists",
    TRUE ~ "Other"
  ))

# 4. VISUALIZE
p1 <- ggplot(df, aes(x=Persona, y=Total_Spend, fill=Persona)) + 
  geom_boxplot() + theme_minimal() + labs(title="Spending Power", y="Spend ($)") +
  theme(legend.position="none")

p2 <- ggplot(df, aes(x=Persona, y=Recency, fill=Persona)) + 
  geom_boxplot() + theme_minimal() + labs(title="Churn Risk", y="Days Since Purchase") +
  theme(legend.position="none")

grid.arrange(p1, p2, ncol=2)

# 5. SAVE & SUMMARY
print("---------------------------------------------------")
print("             FINAL STRATEGY PROFILE (K=4)          ")
print("---------------------------------------------------")

summary_table <- df %>% 
  group_by(Persona) %>%
  summarise(
    Count = n(),
    Avg_Income = round(mean(Income), 0),
    Avg_Spend = round(mean(Total_Spend), 0),
    Avg_Visits = round(mean(NumWebVisitsMonth), 1),
    Avg_Recency = round(mean(Recency), 0),
    Conversion_Rate = round(mean(Response) * 100, 1)
  )

print(summary_table)

write_csv(df, "marketing_campaign_final_4clusters.csv")
print("SUCCESS: Final analysis saved to 'marketing_campaign_final_4clusters.csv'")