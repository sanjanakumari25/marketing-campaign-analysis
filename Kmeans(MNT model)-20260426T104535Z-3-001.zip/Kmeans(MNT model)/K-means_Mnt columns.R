setwd("C:/Users/hites/OneDrive - Institute of Business Administration/IBA/Fall 25-26/AAMD/Term project")
library(dplyr)
library(tidyverse)
list.files()
data <- read_csv("cleaned_data.csv")
data_for_clustering <- data %>% select(MntWines, MntFruits, MntMeatProducts,
                                       MntFishProducts, MntSweetProducts, MntGoldProds)
data_for_clustering_scaled <- scale(data_for_clustering)

kpi_list <- c()
for (i in 2:20){
  clust <- kmeans(data_for_clustering_scaled, centers = i)
  kpi <- clust$betweenss/clust$totss
  print(kpi)
  kpi_list <- c(kpi_list, kpi)
}

plot(x = 2:20, y = kpi_list)

#Taking 7 as number of clusters
set.seed(123)
clust <- kmeans(data_for_clustering_scaled, centers = 7)
clust

##calculating silhoutte score
# Calculate silhouette
install.packages("cluster")
install.packages("factoextra")
library(cluster)
library(factoextra)
sil <- silhouette(clust$cluster, dist(data_for_clustering_scaled))

gging# Print silhouette summary
summary(sil)

# Plot silhouette
plot(sil)


# Add cluster column to original data
data$cluster <- clust$cluster

write_csv(data, "clustered_data_actual.csv")

mean(data$Response == 1) * 100
data %>%
  group_by(cluster) %>%
  summarise(
    total = n(),
    ones = sum(Response == 1),
    percent_ones = mean(Response == 1) * 100
  )

clust$centers

##The clusters that I have made are based on the spending habits of the customers